<?php

return [
    'name' => 'Comment',
];
