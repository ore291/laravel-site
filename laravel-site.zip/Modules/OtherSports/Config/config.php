<?php

return [
    'name' => 'OtherSports'
];
