<?php

return [
    'name' => 'Predictions'
];
