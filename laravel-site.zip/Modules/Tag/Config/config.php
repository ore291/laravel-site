<?php

return [
    'name' => 'Tag',
];
