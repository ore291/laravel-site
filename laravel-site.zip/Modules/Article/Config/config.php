<?php

return [
    'name' => 'Article',
];
