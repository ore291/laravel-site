<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Predictions\\Providers\\PredictionsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Predictions\\Providers\\PredictionsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);