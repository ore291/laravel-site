<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Live\\Providers\\LiveServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Live\\Providers\\LiveServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);