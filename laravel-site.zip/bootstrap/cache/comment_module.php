<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Comment\\Providers\\CommentServiceProvider',
    1 => 'Modules\\Comment\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Comment\\Providers\\CommentServiceProvider',
    1 => 'Modules\\Comment\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);