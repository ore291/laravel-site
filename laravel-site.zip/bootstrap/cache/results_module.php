<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Results\\Providers\\ResultsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Results\\Providers\\ResultsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);