<?php return array (
  'recent-posts' => 'App\\Http\\Livewire\\RecentPosts',
  'users-index' => 'App\\Http\\Livewire\\UsersIndex',
);